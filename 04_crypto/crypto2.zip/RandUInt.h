#pragma once

#include "common.h"

uint RandUInt();
