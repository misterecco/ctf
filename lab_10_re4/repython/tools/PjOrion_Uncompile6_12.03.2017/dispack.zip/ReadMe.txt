------------------------------------------------------------------------
 The simple disassembly package for Python 2.6-3.5
------------------------------------------------------------------------

Last update: 23/05/2016

2014-2016 (C) StranikS_Scan for http://www.koreanrandom.com/forum/