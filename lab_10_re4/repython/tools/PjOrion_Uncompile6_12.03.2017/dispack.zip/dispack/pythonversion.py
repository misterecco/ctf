'''
Python codes and versions
Updated 18.12.2015 by ...Python35-32\Lib\importlib\_bootstrap_external.py
'''

PythonCodeList = {
"Unknown":    0,
"P1.5.x": 20121, # 1.5, 1.5.1, 1.5.2 
"P1.6":   50428, # 1.6
"P2.0.x": 50823, # 2.0, 2.0.1
"P2.1.x": 60202, # 2.1, 2.1.1, 2.1.2
"P2.2":   60717, # 2.2
"P2.3a0": 62011, # 2.3a0
"P2.3a0": 62021, # 2.3a0
"P2.4a0": 62041, # 2.4a0
"P2.4a3": 62051, # 2.4a3
"P2.4b1": 62061, # 2.4b1
"P2.5a0": 62071, # 2.5a0
"P2.5a0": 62081, # 2.5a0 (ast-branch)
"P2.5a0": 62091, # 2.5a0 (with)
"P2.5a0": 62092, # 2.5a0 (changed WITH_CLEANUP opcode)
"P2.5b3": 62101, # 2.5b3 (fix wrong code: for x, in ...)
"P2.5b3": 62111, # 2.5b3 (fix wrong code: x += yield)
"P2.5c1": 62121, # 2.5c1 (fix wrong lnotab with for loops and storing constants that should have been removed
"P2.5c2": 62131, # 2.5c2 (fix wrong code: for x, in ... in listcomp/genexp)
"P2.6a0": 62151, # 2.6a0 (peephole optimizations & STORE_MAP)
"P2.6a1": 62161, # 2.6a1 (WITH_CLEANUP optimization)
"P2.7a0": 62171, # 2.7a0 (optimize list comprehensions/change LIST_APPEND)
"P2.7a0": 62181, # 2.7a0 (optimize conditional branches: introduce POP_JUMP_IF_FALSE and POP_JUMP_IF_TRUE)
"P2.7a0": 62191, # 2.7a0 (introduce SETUP_WITH)
"P2.7a0": 62201, # 2.7a0 (introduce BUILD_SET)
"P2.7a0": 62211, # 2.7a0 (introduce MAP_ADD and SET_ADD)
"P2.7p":  62218, # 2.7 pypy?
"P3.0":   3000,  # 3.000
"P3.0":   3010,  # 3.000 (removed UNARY_CONVERT)
"P3.0":   3020,  # 3.000 (added BUILD_SET)
"P3.0":   3030,  # 3.000 (added keyword-only parameters)
"P3.0":   3040,  # 3.000 (added signature annotations)
"P3.0":   3050,  # 3.000 (print becomes a function)
"P3.0":   3060,  # 3.000 (PEP 3115 metaclass syntax)
"P3.0":   3061,  # 3.000 (string literals become unicode)
"P3.0":   3071,  # 3.000 (PEP 3109 raise changes)
"P3.0":   3081,  # 3.000 (PEP 3137 make __file__ and __name__ unicode)
"P3.0":   3091,  # 3.000 (kill str8 interning)
"P3.0":   3101,  # 3.000 (merge from 2.6a0, see 62151)
"P3.0":   3103,  # 3.000 (__file__ points to source file)
"P3.0a4": 3111,  # 3.0a4 (WITH_CLEANUP optimization)
"P3.0a5": 3131,  # 3.0a5 (lexical exception stacking, including POP_EXCEPT)
"P3.1a0": 3141,  # 3.1a0 (optimize list, set and dict comprehensions)
"P3.1a0": 3151,  # 3.1a0 (optimize conditional branches)
"P3.2a0": 3160,  # 3.2a0 (add SETUP_WITH)
"P3.2a1": 3170,  # 3.2a1 (add DUP_TOP_TWO, remove DUP_TOPX and ROT_FOUR)
"P3.2a2": 3180,  # 3.2a2 (add DELETE_DEREF)
"P3.3a0": 3190,  # 3.3a0  3190 __class__ super closure changed
"P3.3a0": 3200,  # 3.3a0  3200 (__qualname__ added)
"P3.3a0": 3210,  # 3.3a0  3210 (added size modulo 2**32 to the pyc header)
"P3.3a1": 3220,  # 3.3a1  3220 (changed PEP 380 implementation)
"P3.3a4": 3230,  # 3.3a4  3230 (revert changes to implicit __class__ closure)
"P3.4a1": 3250,  # 3.4a1  3250 (evaluate positional default arg keyword-only defaults)
"P3.4a1": 3260,  # 3.4a1  3260 (add LOAD_CLASSDEREF; allow locals of class to override free vars)
"P3.4a1": 3270,  # 3.4a1  3270 (various tweaks to the __class__ closure)
"P3.4a1": 3280,  # 3.4a1  3280 (remove implicit class argument)
"P3.4a4": 3290,  # 3.4a4  3290 (changes to __qualname__ computation)
"P3.4a4": 3300,  # 3.4a4  3300 (more changes to __qualname__ computation)
"P3.4rc2": 3310, # 3.4rc2 3310 (alter __qualname__ computation)
"P3.5a0": 3320,  # 3.5a0  3320 (matrix multiplication operator)
"P3.5b1": 3330,  # 3.5b1  3330 (PEP 448: Additional Unpacking Generalizations)
"P3.5b2": 3340,  # 3.5b2  3340 (fix dictionary display evaluation order #11205)
"P3.5b2": 3350   # 3.5b2  3350 (add GET_YIELD_FROM_ITER opcode #24400)

}

PythonVersionList = dict(zip(PythonCodeList.values(), PythonCodeList.keys()))