'''
New-made module for \Python27\Lib\dis.py
'''

from dis import *
from converter import to_hex31_127hex_escape_as_char

OPCODE_MAX = 147

def get_structure(code):
    """Detect all offsets in a byte code which are jump targets.
    Return the list of offsets.
    """
    structure_opcodes = {93:'| ', 110:'\xb7 ', 111:'\xb7 ', 112:'\xb7 ', 114:'\xb7 ', 115:'\xb7 ', 120:'| ', 121:'+ ', 122:'- ', 143:'* '}
    
    labels = []
    extended_labels = {}
    structure_info = []
    n = len(code)
    i = inst_num = extended_arg = 0
    while i < n:
        try:
            c = code[i]
            op = ord(c)
            i = i+1
            if op >= HAVE_ARGUMENT and op <= OPCODE_MAX and i+1 < n: #fake opcode
                if '<' != opname[op][0]: #fake opcode
                    try:
                        oparg = ord(code[i]) + ord(code[i+1])*256 + extended_arg
                    except:
                        continue #fake arg
                    extended_arg = 0
                    i = i+2
                    if op == EXTENDED_ARG:
                        extended_arg = oparg*65536L
                    label = -1
                    if op in hasjrel:
                        label = i+oparg
                        if op in structure_opcodes:
                            if i<label:
                                structure_info.append({'start': i, 'end': label-1, 'indent': structure_opcodes[op]})
                    elif op in hasjabs:
                        label = oparg
                        if op in structure_opcodes:
                            if i<label:
                                structure_info.append({'start': i, 'end': label-1, 'indent': structure_opcodes[op]})
                    if n > label > -1:
                        if label not in labels:
                            labels.append(label)
                        if label not in extended_labels:
                            extended_labels[label] = [inst_num,]
                        else:
                            extended_labels[label].append(inst_num)
        finally:
            inst_num = inst_num+1
    return labels, extended_labels, structure_info

def findlinestarts(code):
    """Find the offsets in a byte code which are start of lines in the source.
    Generate pairs (offset, lineno) as described in Python/compile.c.
    """
    byte_increments = [ord(c) for c in code.co_lnotab[0::2]]
    line_increments = [ord(c) for c in code.co_lnotab[1::2]]

    lastlineno = None
    lineno = code.co_firstlineno
    addr = 0
    for byte_incr, line_incr in zip(byte_increments, line_increments):
        if byte_incr:
            if lineno != lastlineno:
                yield (addr, lineno)
                lastlineno = lineno
            addr += byte_incr
        lineno += line_incr
    if lineno != lastlineno:
        yield (addr, lineno)

def get_sindents(code, structure):
    sindents = {}
    maxsindent = 0
    n = len(code)
    i = 0
    while i < n:
        c = code[i]
        op = ord(c)
        s = ''
        for x in structure:
            if x['start'] <= i <= x['end']:
                s += x['indent']
        sindents[i] = s
        s = len(s)
        if s > maxsindent:
            maxsindent = s
        i = i+1
        if op >= HAVE_ARGUMENT and op <= OPCODE_MAX and i+1 < n:
            if '<' != opname[op][0]: #fake opcode
                try:
                    oparg = ord(code[i]) + ord(code[i+1])*256
                except:
                    continue #fake arg
                i = i+2
    return sindents, maxsindent

def disassemble(co, lasti=-1):
    """Disassemble a code object."""
    code = co.co_code
    labels, _, structure = get_structure(code)
    sindents, maxsindent = get_sindents(code, structure)
    linestarts = dict(findlinestarts(co))
    n = len(code)
    i = 0
    extended_arg = 0
    free = None
    while i < n:
        c = code[i]
        op = ord(c)
        if i in linestarts:
            if i > 0:
                print
            print "%4d" % linestarts[i],
        else:
            print '    ',
        if i == lasti: print '-->',
        else: print '   ',
        if i in labels: print '>>',
        else: print '  ',
        print repr(i).rjust(4),
        fake_op = False
        if op <= OPCODE_MAX:
            ops = sindents[i] + opname[op]
            if '<' == opname[op][0]:
                fake_op = True
                ops = ops + ' FAKE!' #fake opcode
            print ops.ljust(maxsindent+20),
        else:
            fake_op = True
            print ('%s<%s> FAKE!' % (sindents[i],repr(op))).ljust(maxsindent+20), #fake opcode
        print ('['+code[i].encode('hex').upper()),
        i = i+1
        if op >= HAVE_ARGUMENT and not fake_op and i+1 < n:
            print '%s %s]' % (code[i].encode('hex').upper(), code[i+1].encode('hex').upper()),
            try:
                oparg = ord(code[i]) + ord(code[i+1])*256 + extended_arg
            except:
                continue #fake arg
            extended_arg = 0
            i = i+2
            if op == EXTENDED_ARG:
                extended_arg = oparg*65536L
            print repr(oparg).rjust(5),
            if op in hasconst: 
                print '(%s)' % (str(co.co_consts[oparg]) if (oparg >=0 and oparg < len(co.co_consts)) else 'FAKE!'),
            elif op in hasname:
                print '(%s)' % (to_hex31_127hex_escape_as_char(co.co_names[oparg]) if (oparg >=0 and oparg < len(co.co_names)) else 'FAKE!'),
            elif op in hasjrel:
                print '(to %s)' % repr(i + oparg),
            elif op in hasjabs:
                print ('' if n > oparg > -1 else 'FAKE!'),
            elif op in haslocal:
                print '(%s)' % (to_hex31_127hex_escape_as_char(co.co_varnames[oparg]) if (oparg >=0 and oparg < len(co.co_varnames)) else 'FAKE!'),
            elif op in hascompare:
                print '(%s)' % (cmp_op[oparg] if (oparg >=0 and oparg < len(cmp_op)) else 'FAKE!'),
            elif op in hasfree:
                if free is None:
                    free = co.co_cellvars + co.co_freevars
                print '(%s)' % (free[oparg] if (oparg >=0 and oparg < len(free)) else 'FAKE!'),
        else:
            print '-- --]',
        print

def disassemble_string(code, lasti=-1, varnames=None, names=None,
                       constants=None):
    labels, _, _ = get_structure(code)
    n = len(code)
    i = 0
    while i < n:
        c = code[i]
        op = ord(c)
        if i == lasti: print '-->',
        else: print '   ',
        if i in labels: print '>>',
        else: print '  ',
        print repr(i).rjust(4),
        fake_op = False #<<< new code
        if op <= OPCODE_MAX: 
            ops = opname[op]
            if '<' == ops[0]:
                fake_op = True
                ops = ops + ' FAKE!' #fake opcode
            print ops.ljust(20),
        else:
            fake_op = True
            print ('<%s> FAKE!' % repr(op)).ljust(20), #fake opcode
        print ('['+code[i].encode('hex').upper()),
        i = i+1
        if op >= HAVE_ARGUMENT and not fake_op and i+1 < n:
            print '%s %s]' % (code[i].encode('hex').upper(), code[i+1].encode('hex').upper()),
            try:            
                oparg = ord(code[i]) + ord(code[i+1])*256
            except:
                continue #fake arg
            i = i+2
            print repr(oparg).rjust(5),
            if op in hasconst:
                if constants:
                    print '(%s)' % (str(constants[oparg]) if (oparg >=0 and oparg < len(constants)) else 'FAKE!'),
                else:
                    print '(%d)' % oparg,
            elif op in hasname:
                if names is not None:
                    print '(%s)' % (to_hex31_127hex_escape_as_char(names[oparg]) if (oparg >=0 and oparg < len(names)) else 'FAKE!'),
                else:
                    print '(%d)' % oparg,
            elif op in hasjrel:
                print '(to %s)' % repr(i + oparg),
            elif op in hasjabs:
                print ('' if n > oparg > -1 else 'FAKE!'),
            elif op in haslocal:
                if varnames:
                    print '(%s)' % (to_hex31_127hex_escape_as_char(varnames[oparg]) if (oparg >=0 and oparg < len(varnames)) else 'FAKE!'),
                else:
                    print '(%d)' % oparg,
            elif op in hascompare:
                print '(%s)' % (cmp_op[oparg] if (oparg >=0 and oparg < len(cmp_op)) else 'FAKE!'),
        else:
            print '-- --]',
        print