'''
The converter printing symbols to the chars and hex

Example:
print '\x03\xf3\r\n_\xf1\xd8Sc'
<<< ?
<<< _??Sc
'''

backslash = chr(92)
prefix = backslash+"x"

def to_127hex(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \xf3
    <<< _\xf1\xd8Sc
    '''
    return "".join((v if ord(v)<127 else '%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0"))) for v in message) \
            if len(message)>0 else message

def to_hex31_127hex_escape_as_hex(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3\x0d\x0a_\xf1\xd8Sc
    '''
    return "".join((v if 31<ord(v)<127 else '%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0"))) for v in message) \
            if len(message)>0 else message

def to_hex31_127hex_escape_as_symbol(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3
    <<< _\xf1\xd8Sc
    '''
    return ("".join((((v if ord(v) in [10, 7, 8, 12, 13, 9, 11] else \
                       ('%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0")) \
                       ) \
                      ) if ord(v)<32 else v \
                     ) if ord(v)<127 else '%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0")) \
                    ) for v in message \
                   ) \
           ) if len(message)>0 else message
    
def to_hex31_127hex_escape_as_char(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3\r\n_\xf1\xd8Sc
    '''
    return ("".join(((("%sn" % backslash if ord(v)==10 else \
                          ("%sa" % backslash if ord(v)==7 else \
                              ("%sb" % backslash if ord(v)==8 else \
                                  ("%sf" % backslash if ord(v)==12 else \
                                      ("%sr" % backslash if ord(v)==13 else \
                                          ("%st" % backslash if ord(v)==9 else \
                                              ("%sv" % backslash if ord(v)==11 else \
                                                  ('%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0")) \
                                                  ) \
                                              )\
                                          ) \
                                      ) \
                                  ) \
                              ) \
                          ) \
                      ) if ord(v)<32 else v \
                     ) if ord(v)<127 else '%s%s' % (prefix, hex(ord(v))[2:].rjust(2,"0")) \
                    ) for v in (message[:-1] if ord(message[-1])==10 else message) \
                   )+ \
            (chr(10) if ord(message[-1])==10 else "") \
           ) if len(message)>0 else message
