'''
The basic functions to disassemble pyc-files
'''

# Speed tester  ------------------------------------------------------

import cProfile

def profile(func):
    def wrapper(*args, **kwargs):
        profiler = cProfile.Profile()
        result = profiler.runcall(func, *args, **kwargs)
        profiler.dump_stats(func.__name__ + '.prof')
        return result
    return wrapper

# Output buffering  ------------------------------------------------------

out_buffer = ''
store_stdout = store_stderr = None

class DisStdErrHook:
    def write(self, message):
        pass
    def flush(self):
        pass
    def close(self):
        pass

class DisStdOutHook:
    def write(self, message):
        global out_buffer
        if message and out_buffer:
            if message == '\n' == out_buffer[-1]:
                return
        out_buffer += str(message)
    def flush(self):
        pass
    def close(self):
        pass

def set_output_hook():
    import sys
    global store_stdout, store_stderr, out_buffer
    out_buffer = ''
    store_stdout = sys.stdout
    sys.stdout = DisStdOutHook()
    #store_stderr = sys.stderr    #<<< off
    #sys.stderr = DisStdErrHook() #<<< off

def remove_output_hook():
    import sys
    global store_stdout, store_stderr
    #sys.stderr = store_stderr    #<<< off
    #store_stderr = None          #<<< off
    sys.stdout = store_stdout
    store_stdout = None

# Output and converting functions ------------------------------------------------------ 

import base64

def get_hex(code, prefix='', split=''):
    code = base64.b16encode(code).decode('UTF-8')
    if code:
        code = split.join([(prefix+code[i:i + 2]) for i in range(0, len(code), 2)])
    return code    

def show_hex(code, label='', indent='', prefix='', split='', byteinline=16):
    '''
    Return string as:
    <indentlabel prefix00splitprefix01splitprefix10 ....>
    or
    <indentlabel
              prefix00splitprefix01splitprefix10 ....>
    if the code length is more than byteinline                     
    '''
    code = get_hex(code, prefix, split)
    maxlength = (2+len(split))*byteinline
    if len(code) < maxlength:
        if label:
            print("%s%s %s" % (indent, label, code))
        else:
            print("%s%s" % (indent, code))    
    else:
        if label:
            print("%s%s" % (indent, label))
            for i in range(0, len(code), maxlength):
                print("%s   %s" % (indent, code[i:i+maxlength]))
        else:
            for i in range(0, len(code), maxlength):
                print("%s%s" % (indent, code[i:i+maxlength]))            

# System analysis ----------------------------------------------------------------------

def get_compiler_version(magic):
    from imp import get_magic
    from struct import unpack
    from pythonversion import PythonVersionList
    try:
        number = unpack('<i', magic[:2]+b'\x00\x00')[0]
    except:
        number = 0
    if number not in PythonVersionList:
        number = 0
    return {'python': PythonVersionList[number], \
            'number': str(number), \
            'magic': get_hex(magic,'\\x')}

def get_python_version():   
    from imp import get_magic
    from struct import unpack
    from pythonversion import PythonVersionList
    magic = get_magic()
    return get_compiler_version(magic)

# File analysis ------------------------------------------------------------------------

def get_info_file(filename):
    '''
    Read and return file info 
    '''
    from marshal import load
    import time, struct
    try:
        f = open(filename,'rb')
        try:
            magic = f.read(4)
            moddate = f.read(4)
            modtime = time.asctime(time.localtime(struct.unpack('L', moddate)[0]))        
            try:
                code = load(f)
            except:
                f.seek(0)
                f.read(12)
                code = load(f)
        finally:
            f.close() 
    except Exception as E:
        print(str(E))
        return None
    else:
        return {'code': code, \
                'modtime': modtime, \
                'moddate': moddate, \
                'magic':magic}    

def get_bytecode_file(filename):
    info = get_info_file(filename)
    if info is not None:
        return info['code']
    else:
        return None

def get_compiler_file(filename):
    from imp import get_magic
    from struct import unpack
    from pythonversion import PythonVersionList
    magic = open(filename, "rb").read(4)
    return get_compiler_version(magic) 

def show_code(code, Py3x=False, deep=True, indent='', level=0):
    '''
    Code analysis and print info. Syntax highlighting in Orion adapted to this format
    '''
    import types
    print("%s******************** code beginning (level %d) ********************" % (indent, level))
    print("%sargcount:    %d" % (indent, code.co_argcount))
    if Py3x:
        print("%skwonlyargcount:    %d" % (indent, code.co_kwonlyargcount))
    print("%snlocals:     %d" % (indent, code.co_nlocals))
    print("%sstacksize:   %d" % (indent, code.co_stacksize))
    print("%sflags:       %04x" % (indent, code.co_flags))
    show_hex(code.co_code, "hexcode:",  indent, '', ' ')
    print("%sconsts:" % indent)
    for const in code.co_consts:
        print("   %s(%d) %r" % (indent, code.co_consts.index(const),const))
        if type(const) == types.CodeType and deep:
            show_code(const, Py3x, deep, indent+'      ', level+1)
    print("%snames:       %r" % (indent, code.co_names))
    print("%svarnames:    %r" % (indent, code.co_varnames))
    print("%sfreevars:    %r" % (indent, code.co_freevars))
    print("%scellvars:    %r" % (indent, code.co_cellvars))
    print("%sfilename:    %r" % (indent, code.co_filename))
    print("%sname:        %r" % (indent, code.co_name))
    print("%sfirstlineno: %d" % (indent, code.co_firstlineno))
    show_hex(code.co_lnotab, "lnotab:", indent, '', ' ')
    print("%s********************** code ending (level %d) *********************" % (indent, level))

#@profile    
def show_file(filename):
    '''
    Print all info about pyc-file
    '''
    global out_buffer
    print("File: "+filename)
    print("------------------------------------------------------------------")
    compiler = get_compiler_file(filename)
    info = get_info_file(filename)
    pyVer = get_python_version()
    if info is not None:
        set_output_hook()
        try:
            print("Python: %s: %s" % (compiler["python"], compiler["number"]))
            print("Magic:   %s" % (get_hex(info["magic"],"\\x")))
            print("ModDate: %s (%s)" % (get_hex(info["moddate"],"\\x"), info["modtime"]))
            show_code(info["code"], 'P3' in pyVer['python'])
        finally:
            remove_output_hook()
        if out_buffer:
            if out_buffer[-1] == '\n':
                out_buffer = out_buffer[:-1] #remove eol in text's end
            print(out_buffer)
    else:
        print("Check the compiler's version of this file!")

#@profile
def dump_file(filename):
    '''
    Dump all info about pyc-file to *.info.txt on disk
    '''
    import os.path
    global out_buffer
    logname,_ = os.path.splitext(filename)
    if os.path.isfile(logname+'.info.txt'):
        i = 1
        while os.path.isfile(logname+('.info%d.txt' % i)):
            i += 1
        logname += ('.info%d.txt' % i)
    else:
        logname += '.info.txt'
    print(logname)
    with open(logname,'w') as file:
        compiler = get_compiler_file(filename)
        info = get_info_file(filename)
        pyVer = get_python_version()
        if info is not None:
            set_output_hook()
            try:
                file.write("Python: %s: %s\n" % (compiler["python"], compiler["number"]))
                file.write("Magic:   %s\n" % (get_hex(info["magic"],"\\x")))
                file.write("ModDate: %s (%s)\n" % (get_hex(info["moddate"],"\\x"), info["modtime"]))
                show_code(info["code"], 'P3' in pyVer['python'])
            finally:
                remove_output_hook()
            if out_buffer:
                file.write(out_buffer)
        else:
            file.write("Check the compiler's version of this file!")

def show_compiler_file(filename):
    '''
    Print compiler's version of pyc-file
    '''
    print("File: "+filename)
    compiler = get_compiler_file(filename)
    print("Python: %s: %s (%s)" % (compiler["python"], compiler["number"], compiler["magic"]))
    
# Dis ----------------------------------------------------------------------------------

def dis_code(code, deep=True, indent='', level=0):
    '''
    Disassemble bytecode and print info. Syntax highlighting in Orion adapted to this format
    '''           
    import types
    global out_buffer
    pyVer = get_python_version()
    if 'P3' in pyVer['python']: #FOR PYTHON 3.X
        import disassemble_3 as dis_module
        _have_code = (types.MethodType, types.FunctionType, types.CodeType, type)
        if code is None:
            return
        if hasattr(code, '__func__'): # Method
            code = code.__func__
        if hasattr(code, '__code__'): # Function
            code = code.__code__
        if hasattr(code, '__dict__'): # Class or module
            items = sorted(code.__dict__.items())
            for name, code1 in items:
                if isinstance(code1, _have_code) and deep:
                    print("# Disassembly of '%s':" % name)
                    try:
                        dis_code(code1, deep, indent, level)
                    except TypeError as msg:
                        print("Error:", msg)
        elif hasattr(code, 'co_code'): # Code object
            print("%s******************** code beginning (level %d) ********************" % (indent, level))
            print("%sdiscode[hexcode]:" % indent)
            store_out_buffer = out_buffer
            out_buffer = ''
            dis_module.disassemble(code)
            if out_buffer:
                if out_buffer[-1] == '\n':
                    out_buffer = out_buffer[:-1] #remove eol in text's end                
                out_buffer = ('%s|' % indent)+out_buffer.replace('\n',('\n%s|' % indent))
            out_buffer = store_out_buffer + out_buffer + '\n'
            if hasattr(code, 'co_consts'):
                print("%sconsts:" % indent)
                for const in code.co_consts:
                    print("   %s(%d) %r" % (indent, code.co_consts.index(const), const))
                    if type(const) == types.CodeType and deep:
                        dis_code(const, deep, indent+'      ', level+1)
            print("%s********************** code ending (level %d) *********************" % (indent, level))
        elif isinstance(code, (bytes, bytearray)): # Raw bytecode
            print("%s******************** code beginning (level %d) ********************" % (indent, level))
            print("%sdiscode[hexcode]:" % indent)
            store_out_buffer = out_buffer
            out_buffer = ''
            dis_module._disassemble_bytes(code)
            if out_buffer:
                if out_buffer[-1] == '\n':
                    out_buffer = out_buffer[:-1] #remove eol in text's end
                out_buffer = ('%s|' % indent)+out_buffer.replace('\n',('\n%s|' % indent))
            out_buffer = store_out_buffer + out_buffer + '\n'
            print("%s********************** code ending (level %d) *********************" % (indent, level))
        elif isinstance(code, str):
            print("%s******************** code beginning (level %d) ********************" % (indent, level))
            print("%sdiscode[hexcode]:" % indent)
            store_out_buffer = out_buffer
            out_buffer = ''
            dis_module._disassemble_str(code)
            if out_buffer:
                if out_buffer[-1] == '\n':
                    out_buffer = out_buffer[:-1] #remove eol in text's end
                out_buffer = ('%s|' % indent)+out_buffer.replace('\n',('\n%s|' % indent))
            out_buffer = store_out_buffer + out_buffer + '\n'
            print("%s********************** code ending (level %d) *********************" % (indent, level))
        else:
            print("Error: Don't know how to disassemble '%s' objects" % type(code).__name__)                        
    else: #FOR PYTHON 2.X
        import disassemble_2 as dis_module
        _have_code = (types.MethodType, types.FunctionType, types.CodeType, types.ClassType, type)
        if code is None:
            return
        if isinstance(code, types.InstanceType):
            code = code.__class__
        if hasattr(code, 'im_func'):
            code = code.im_func
        if hasattr(code, 'func_code'):
            code = code.func_code
        if hasattr(code, '__dict__'):
            items = code.__dict__.items()
            items.sort()
            for name, code1 in items:
                if isinstance(code1, _have_code) and deep:
                    print("# Disassembly of '%s':" % name)
                    try:
                        dis_code(code1, deep, indent, level)
                    except TypeError as msg:
                        print("Error:", msg)
        elif hasattr(code, 'co_code'):
            print("%s******************** code beginning (level %d) ********************" % (indent, level))
            print("%sdiscode[hexcode]:" % indent)
            store_out_buffer = out_buffer
            out_buffer = ''
            dis_module.disassemble(code)
            if out_buffer:
                if out_buffer[-1] == '\n':
                    out_buffer = out_buffer[:-1] #remove eol in text's end
                out_buffer = ('%s|' % indent)+out_buffer.replace('\n',('\n%s|' % indent))
            out_buffer = store_out_buffer + out_buffer + '\n'
            if hasattr(code, 'co_consts'):
                print("%sconsts:" % indent)
                for const in code.co_consts:
                    print("   %s(%d) %r" % (indent, code.co_consts.index(const), const))
                    if type(const) == types.CodeType and deep:
                        dis_code(const, deep, indent+'      ', level+1)
            print("%s********************** code ending (level %d) *********************" % (indent, level))
        elif isinstance(code, str):
            print("%s******************** code beginning (level %d) ********************" % (indent, level))
            print("%sdiscode[hexcode]:" % indent)
            store_out_buffer = out_buffer
            out_buffer = ''
            dis_module.disassemble_string(code)
            if out_buffer:
                if out_buffer[-1] == '\n':
                    out_buffer = out_buffer[:-1] #remove eol in text's end
                out_buffer = ('%s|' % indent)+out_buffer.replace('\n',('\n%s|' % indent))
            out_buffer = store_out_buffer + out_buffer + '\n'
            print("%s********************** code ending (level %d) *********************" % (indent, level))
        else:
            print("Error: Don't know how to disassemble '%s' objects" % type(code).__name__)

def dis_object(object, name=''):
    '''
    Disassemble bytecode of any Object
    '''
    global out_buffer
    print("Object: "+type(object).__name__+" "+("\'%s\'" % name if name else ""))
    print("------------------------------------------------------------------")
    set_output_hook()
    try:
        dis_code(object)
    finally:
        remove_output_hook()
    if out_buffer:
        if out_buffer[-1] == '\n':
            out_buffer = out_buffer[:-1] #remove eol in text's end
        print(out_buffer)

#@profile    
def dis_file(filename):
    '''
    Disassemble pyc-file's bytecode
    '''
    global out_buffer
    print("File: "+filename)
    print("------------------------------------------------------------------")
    info = get_info_file(filename)
    if info is not None:
        set_output_hook()
        try:
            dis_code(info["code"])
        finally:
            remove_output_hook()
        if out_buffer:
            if out_buffer[-1] == '\n':
                out_buffer = out_buffer[:-1] #remove eol in text's end
            print(out_buffer)
    else:
        print("Check the compiler's version of this file!")
        
#@profile
def dis_file_to_txt(filename):
    '''
    Disassemble pyc-file's bytecode to *.dis.txt on disk
    '''
    import os.path
    global out_buffer
    logname,_ = os.path.splitext(filename)
    if os.path.isfile(logname+'.dis.txt'):
        i = 1
        while os.path.isfile(logname+('.dis%d.txt' % i)):
            i += 1
        logname += ('.dis%d.txt' % i)
    else:
        logname += '.dis.txt'
    print(logname)
    with open(logname,'w') as file:
        info = get_info_file(filename)
        if info is not None:
            set_output_hook()
            try:
                dis_code(info["code"])
            finally:
                remove_output_hook()
            if out_buffer:
                file.write(out_buffer)
        else:
            file.write("Check the compiler's version of this file!")