'''
The wot-transmission initialization
'''

# Load code of the original module --------------------------------------------------

from zipfile import ZipFile
from marshal import loads

def GetNameIndex(co_consts, name):
    from types import CodeType
    for i, const in enumerate(co_consts):
        if type(const) == CodeType and const.co_name == name:
            return i
    return -1

script = \
'class LOG_LEVEL:'+'\n'+\
'    DEV = 1'+'\n'+\
'    ST = 2'+'\n'+\
'    CT = 3'+'\n'+\
'    SVR_RELEASE = 4'+'\n'+\
'    RELEASE = 5' #Replace to 1 for extended log-info

code = compile(script,'','exec')

with ZipFile('./res/packages/scripts.pkg', 'r') as z:
    with z.open('scripts/common/debug_utils.pyc') as f:
        module = loads(f.read()[8:])

new_co_consts = [x for x in module.co_consts]
new_co_consts[GetNameIndex(module.co_consts, 'LOG_LEVEL')] = code.co_consts[GetNameIndex(code.co_consts, 'LOG_LEVEL')]

module = type(module)(module.co_argcount, \
                      module.co_nlocals, \
                      module.co_stacksize, \
                      module.co_flags, \
                      module.co_code, \
                      tuple(new_co_consts), \
                      module.co_names, \
                      module.co_varnames, \
                      module.co_filename, \
                      module.co_name, \
                      module.co_firstlineno, \
                      module.co_lnotab, \
                      module.co_freevars, \
                      module.co_cellvars)

exec module in globals()

# WOT-Transmission ------------------------------------------------------------------

from sys import path as syspath
from os import path as ospath
from os import remove

wwt_zipfile = '$WOTTransmission$'
outpath = '$OutPath$'
refreshinterval = $RefreshInterval$
printingsymbolsmode = $PrintingSymbolsMode$

try:
    basepath = wwt_zipfile.replace(ospath.basename(wwt_zipfile),'')
    dcp_zipfile = basepath+'dcpack.zip'
    dis_zipfile = basepath+'dispack.zip'
    syspath.insert(0, basepath)
    syspath.insert(0, dcp_zipfile)
    syspath.insert(0, dcp_zipfile+'/dcpack')    
    syspath.insert(0, dis_zipfile)
    syspath.insert(0, dis_zipfile+'/dispack')     
    syspath.insert(0, wwt_zipfile)
    syspath.insert(0, wwt_zipfile+'/wottransmission')
    from wottransmission.transmitter import orion_transfer_init
    orion_transfer_init(outpath, refreshinterval, printingsymbolsmode)
    remove(outpath + 'debug_utils.pyc')
except Exception as E:
    print 'Error: WOT-Transmission in client is not initialized! (%s)' % str(E) 
    import traceback
    traceback.format_exc()

