'''
The file-mutex for transfer status signaling

lock buffers -> if mutex-file is exists
unlock buffers -> if mutex-file deleted
'''

from os import access, F_OK, W_OK, remove

class Mutex(object):
    def __init__(self, path, name='mutex'):
        self.filename = path + name
        self.file = None
    
    def check(self):
        try:
            return access(self.filename, F_OK)
        except:
            return True    
    
    def lock(self):
        if not self.check():
            try:
                self.file = open(self.filename, 'w')
                self.file.write('LOCK')
                self.file.close()
                self.file = None
            except:
                return False
        return True
    
    def unlock(self):
        if self.check():
            if access(self.filename, W_OK):
                try:
                    remove(self.filename)
                except:
                    return False
            else:
                return False
        return True