'''
The transmitter for WorldOfTanks

client_mutex = on -> client using buffers
orion_mutex = on -> orion using buffers

client_buffer -> client - write, orion - read/free
orion_buffer  -> client - read/free, orion - write
'''

import BigWorld
import sys
from os import path as ospath
import threading
import time
from mutex import Mutex
from buffer import Buffer
from module import rebuild_module, delete_module 

client_mutex  = None
client_buffer = None
orion_mutex   = None
orion_buffer  = None

message_buffer = ''
sleep_buffer   = ''

wottransmission_thread           = None
wottransmission_enable           = True
wottransmission_sleep            = False
wottransmission_output_buffering = False
wottransmission_printingsymbolsmode = 0

def orion_bwmessages_hook(prefix, msg, func):
    func(prefix, msg, None)
    if wottransmission_enable:
        global message_buffer
        global client_mutex, client_buffer, orion_mutex
        text = str(prefix)+str(msg)
        if text:
            text += '\n'
        if not wottransmission_sleep:
            if not wottransmission_output_buffering or (len(message_buffer)>=5000):
                if not orion_mutex.check():
                    if client_mutex.lock():
                        try:
                            client_buffer.write(message_buffer+text, wottransmission_printingsymbolsmode)
                            text = message_buffer = ''
                        finally:
                            client_mutex.unlock()
        if text:
            message_buffer += str(text)        

class orion_debugoutput():
    def write(self, message):
        sys.stdout_9DE33FC23B674F7BBBEB88AE117FF1D5.write(message)
        
        global message_buffer
        global client_mutex, client_buffer, orion_mutex        
        if message or message_buffer:
            if not wottransmission_sleep:
                if not wottransmission_output_buffering or (len(message_buffer)>=5000):
                    if not orion_mutex.check():
                        if client_mutex.lock():
                            try:
                                client_buffer.write(message_buffer+str(message), wottransmission_printingsymbolsmode)
                                message = message_buffer = ''
                            finally:
                                client_mutex.unlock()
            if message:
                message_buffer += str(message)
    def flush(self):
        sys.stdout_9DE33FC23B674F7BBBEB88AE117FF1D5.flush()
    def close(self):
        pass

def orion_transfer_check():
    global wottransmission_enable, wottransmission_printingsymbolsmode
    global wottransmission_sleep, sleep_buffer
    global client_mutex, orion_mutex, orion_buffer
    if not orion_mutex.check():
        if client_mutex.lock():
            try:
                if orion_buffer.check():
                    code = orion_buffer.read()
                    if code:
                        if not wottransmission_sleep or ('wottransmission_sleep=False' in code.replace(' ', '')):
                            try:
                                if sleep_buffer:
                                    exec compile(sleep_buffer,'','exec') in sys.modules['__main__'].__dict__
                                exec compile(code,'','exec') in sys.modules['__main__'].__dict__
                            except:
                                import traceback
                                print traceback.format_exc()
                                return False
                            finally:
                                sleep_buffer = ''
                        else:
                            sleep_buffer += str(code)
                    return True
            finally:
                client_mutex.unlock()                
    return False

def wottransmission_loop(refreshinterval):
    while wottransmission_enable:
        orion_transfer_check()
        time.sleep(refreshinterval)
    if hasattr(sys, 'stdout_9DE33FC23B674F7BBBEB88AE117FF1D5'):
        sys.stdout=sys.stdout_9DE33FC23B674F7BBBEB88AE117FF1D5
    if hasattr(sys, 'stderr_9DE33FC23B674F7BBBEB88AE117FF1D5'):
        sys.stderr=sys.stderr_9DE33FC23B674F7BBBEB88AE117FF1D5

def orion_transfer_init(path='', refreshinterval=0.1, printingsymbolsmode=0):
    global wottransmission_thread, wottransmission_printingsymbolsmode
    global client_mutex, client_buffer, orion_mutex, orion_buffer
    try:
        if ospath.exists(path):
            client_mutex = Mutex(path, 'client_mutex')
            client_buffer = Buffer(path, 'client_buffer')
            orion_mutex = Mutex(path, 'orion_mutex')
            orion_buffer = Buffer(path, 'orion_buffer')
            if client_mutex.check():           
                sys.stdout_9DE33FC23B674F7BBBEB88AE117FF1D5 = sys.stdout
                sys.stderr_9DE33FC23B674F7BBBEB88AE117FF1D5 = sys.stderr
                sys.stderr = sys.stdout = orion_debugoutput()
                
                bwLogTrace = BigWorld.logTrace
                BigWorld.logTrace = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogTrace)               
                bwLogDebug = BigWorld.logDebug
                BigWorld.logDebug = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogDebug)
                bwLogInfo = BigWorld.logInfo
                BigWorld.logInfo = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogInfo)
                bwLogNotice = BigWorld.logNotice
                BigWorld.logNotice = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogNotice)
                bwLogWarning = BigWorld.logWarning
                BigWorld.logWarning = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogWarning)
                bwLogError = BigWorld.logError
                BigWorld.logError = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogError)
                bwLogCritical = BigWorld.logCritical
                BigWorld.logCritical = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogCritical)
                bwLogHack = BigWorld.logHack
                BigWorld.logHack = lambda prefix, msg, *args: orion_bwmessages_hook(prefix, msg, bwLogHack)
                
                wottransmission_printingsymbolsmode = printingsymbolsmode
                wottransmission_thread = threading.Thread(target=wottransmission_loop, args=(refreshinterval,))
                wottransmission_thread.daemon = True
                if orion_transfer_check():
                    wottransmission_thread.start()
    except Exception as E:
        print str(E)