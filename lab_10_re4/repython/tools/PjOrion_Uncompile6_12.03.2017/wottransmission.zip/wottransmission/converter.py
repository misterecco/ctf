'''
The converter printing symbols to the chars and hex

Example:
print '\x03\xf3\r\n_\xf1\xd8Sc'
<<< ?
<<< _??Sc
'''

#import cProfile

#def profile(func):
#    def wrapper(*args, **kwargs):
#        profiler = cProfile.Profile()
#        result = profiler.runcall(func, *args, **kwargs)
#        profiler.dump_stats(func.__name__ + '.prof')
#        return result
#    return wrapper

#@profile
def to_127hex(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \xf3
    <<< _\xf1\xd8Sc
    '''
    return "".join((chr(v) if v<127 else '\\x%s' % hex(v)[2:].rjust(2,"0")) for v in map(ord,message)) if message else message

#@profile
def to_hex31_127hex_escape_as_hex(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3\x0d\x0a_\xf1\xd8Sc
    '''
    return "".join((chr(v) if 31<v<127 else '\\x%s' % hex(v)[2:].rjust(2,"0")) for v in map(ord,message)) if message else message

#@profile
def to_hex31_127hex_escape_as_symbol(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3
    <<< _\xf1\xd8Sc
    '''
    return ("".join((((chr(v) if v in [10, 7, 8, 12, 13, 9, 11] else ('\\x%s' % hex(v)[2:].rjust(2,"0")) \
                      ) if v<32 else chr(v) \
                     ) if v<127 else '\\x%s' % hex(v)[2:].rjust(2,"0") \
                    ) for v in map(ord,message) \
                   ) \
           ) if message else message

#@profile
def to_hex31_127hex_escape_as_char(message):
    '''
    Example:
    print '\x03\xf3\r\n_\xf1\xd8Sc'
    <<< \x03\xf3\r\n_\xf1\xd8Sc
    '''
    return ("".join(((("\\n" if v==10 else \
                          ("\\a" if v==7 else \
                              ("\\b" if v==8 else \
                                  ("\\f" if v==12 else \
                                      ("\\r" if v==13 else \
                                          ("\\t" if v==9 else \
                                              ("\\v" if v==11 else \
                                                  ("\\x%s" % hex(v)[2:].rjust(2,"0") \
                                                  ) \
                                              )\
                                          ) \
                                      ) \
                                  ) \
                              ) \
                          ) \
                      ) if v<32 else chr(v) \
                     ) if v<127 else "\\x%s" % hex(v)[2:].rjust(2,"0") \
                    ) for v in map(ord,(message[:-1] if message[-1]=='\n' else message))) + ('\n' if message[-1]=='\n' else "") \
           ) if message else message
