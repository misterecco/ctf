'''
The file-buffer for data transfer
'''

from os import access, F_OK, R_OK, W_OK, remove
from converter import to_hex31_127hex_escape_as_symbol, to_hex31_127hex_escape_as_char

class Buffer(object):
    def __init__(self, path, name='buffer'):
        self.filename = path + name
        self.file = None

    def check(self):
        try:
            return access(self.filename, F_OK)
        except:
            return False

    def write(self, text='', printingsymbolsmode=0):
        if not self.check() or access(self.filename, W_OK):
            try:
                self.file = open(self.filename, 'a')
                try:
                    if printingsymbolsmode == 1:
                        self.file.write(to_hex31_127hex_escape_as_symbol(text))
                    elif printingsymbolsmode == 2:
                        self.file.write(to_hex31_127hex_escape_as_char(text))
                    else:
                        self.file.write(text)
                finally:
                    self.file.close()
                    self.file = None
            except:
                return False
        else:
            return False
        return True    

    def read(self, clear=True):
        try:
            if self.check() and access(self.filename, R_OK):
                try:
                    self.file = open(self.filename, 'r')
                    try:
                        return self.file.read()
                    finally:
                        self.file.close()
                        self.file = None
                finally:
                    if clear:
                        self.clear()
            else:
                return ''
        except:
            return ''
    
    def clear(self):
        if self.check():
            if access(self.filename, W_OK):
                try:
                    remove(self.filename)
                except:
                    return False
            else:
                return False
        return True