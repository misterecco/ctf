"""
*Real* reloading support for Python.
"""

# System Imports --------------------------------------------------------------------

import sys
import types
import linecache

# Sibling Imports -------------------------------------------------------------------

__modDictIDMap = {}

def latestFunction(oldFunc):
    """
    Get the latest version of a function.
    """
    # This may be CPython specific, since I believe jython instantiates a new
    # module upon reload.
    dictID = id(oldFunc.func_globals)
    module = __modDictIDMap.get(dictID)
    if module is None:
        return oldFunc
    return getattr(module, oldFunc.__name__)

def namedModule(name):
    """
    Return a module given it's name.
    """
    topLevel = __import__(name)
    packages = name.split(".")[1:]
    m = topLevel
    for p in packages:
        m = getattr(m, p)
    return m

def latestClass(oldClass):
    """
    Get the latest version of a class.
    """
    module = namedModule(oldClass.__module__)
    newClass = getattr(module, oldClass.__name__)
    newBases = [latestClass(base) for base in newClass.__bases__]
    try:
        # This makes old-style stuff work
        newClass.__bases__ = tuple(newBases)
        return newClass
    except TypeError:
        if newClass.__module__ == "__builtin__":
            # __builtin__ members can't be reloaded sanely
            return newClass
        ctor = getattr(newClass, '__metaclass__', type)
        return ctor(newClass.__name__, tuple(newBases), dict(newClass.__dict__))

def updateInstance(self):
    """
    Updates an instance to be current.
    """
    try:
        self.__class__ = latestClass(self.__class__)
    except TypeError:
        if hasattr(self.__class__, '__slots__'):
            print "Can't rebuild class with __slots__ on Python < 2.6"
        else:
            raise

def __getattr__(self, name):
    """
    A getattr method to cause a class to be refreshed.
    """
    if name == '__del__':
        raise AttributeError("Without this, Python segfaults")
    updateInstance(self)
    result = getattr(self, name)
    return result

def rebuild_module(module):
    """
    Reload a module and do as much as possible to replace its references.
    """
    d = module.__dict__
    __modDictIDMap[id(d)] = module
    newclasses = {}
    classes = {}
    functions = {}
    values = {}
    for k, v in d.items():
        if type(v) == types.ClassType:
            # Failure condition -- instances of classes with buggy
            # __hash__/__cmp__ methods referenced at the module level...
            if v.__module__ == module.__name__:
                classes[v] = 1
        elif type(v) == types.FunctionType:
            if v.func_globals is module.__dict__:
                functions[v] = 1
        elif isinstance(v, type):
            if v.__module__ == module.__name__:
                newclasses[v] = 1
    values.update(classes)
    values.update(functions)
    fromOldModule = values.has_key
    newclasses = newclasses.keys()
    classes = classes.keys()
    functions = functions.keys()
    # Boom.
    reload(module)
    # Make sure that my traceback printing will at least be recent...
    linecache.clearcache()
    for clazz in classes:
        if getattr(module, clazz.__name__) is clazz:
            print ("WARNING: class %s not replaced by reload!" % (clazz.__module__ + '.' + clazz.__name__))
        else:
            clazz.__bases__ = ()
            clazz.__dict__.clear()
            clazz.__getattr__ = __getattr__
            clazz.__module__ = module.__name__
    if newclasses:
        import gc
    for nclass in newclasses:
        ga = getattr(module, nclass.__name__)
        if ga is nclass:
            print ("WARNING: new-class %s not replaced by reload!" % (nclass.__module__ + '.' + nclass.__name__))
        else:
            for r in gc.get_referrers(nclass):
                if getattr(r, '__class__', None) is nclass:
                    r.__class__ = ga
    # Refresh all links
    for mk, mod in sys.modules.items():
        if mod == module or mod is None:
            continue
        if not hasattr(mod, '__file__'):
            # It's a builtin module; nothing to replace here.
            continue
        for k, v in mod.__dict__.items():
            try:
                hash(v)
            except Exception:
                continue
            if fromOldModule(v):
                if type(v) == types.ClassType:
                    nv = latestClass(v)
                else:
                    nv = latestFunction(v)
                setattr(mod, k, nv)
            else:
                # Replace bases of non-module classes just to be sure.
                if type(v) == types.ClassType:
                    for base in v.__bases__:
                        if fromOldModule(base):
                            latestClass(v)
    return module

def delete_module(module):
    """
    Delete a module and do as much as possible to delete its references.
    """
    itselfmodule = {}
    newclasses = {}
    classes = {}
    functions = {}
    values = {}
    for k, v in module.__dict__.items():
        if type(v) == types.ClassType:
            # Failure condition -- instances of classes with buggy
            # __hash__/__cmp__ methods referenced at the module level...
            if v.__module__ == module.__name__:
                classes[v] = 1
        elif type(v) == types.FunctionType:
            if v.func_globals is module.__dict__:
                functions[v] = 1
        elif isinstance(v, type):
            if v.__module__ == module.__name__:
                newclasses[v] = 1            
    itselfmodule[module] = 1
    values.update(classes)
    values.update(functions)
    values.update(newclasses)
    values.update(itselfmodule)
    fromOldModule = values.has_key
    # Make sure that my traceback printing will at least be recent...
    linecache.clearcache()
    for clazz in classes:
        if getattr(module, clazz.__name__) is clazz:
            print "WARNING: class %s not be deleted from other modules!" % (clazz.__module__ + '.' + clazz.__name__)
        else:
            clazz.__bases__ = ()
            clazz.__dict__.clear()
            clazz.__getattr__ = __getattr__
            clazz.__module__ = module.__name__
    if newclasses:
        import gc
    for nclass in newclasses:
        ga = getattr(module, nclass.__name__)
        if ga is nclass:
            print "WARNING: new-class %s not be deleted from other modules!" % (nclass.__module__ + '.' + nclass.__name__)
        else:
            for r in gc.get_referrers(nclass):
                if getattr(r, '__class__', None) is nclass:
                    r.__class__ = ga        
    # Delete all links
    for mk, mod in sys.modules.items():
        if mod == module or mod is None:
            continue
        if not hasattr(mod, '__file__'):
            # It's a builtin module; nothing to replace here.
            continue            
        for k, v in mod.__dict__.items():
            try:
                hash(v)
            except Exception:
                continue
            if fromOldModule(v):
                delattr(mod, k)
                print ('del '+str(mod.__name__)+'.'+str(k))
    # Delete module
    try:
        del sys.modules[module.__name__]
    except:
        pass