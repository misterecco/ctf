"""
Package with core functions for decompiling pyc-files.
"""

__all__ = ["orion_decompile_fupy_2", \
           "orion_decompile_uncompyle6_2", \
           "orion_decompile_pyretic_2", \
           "orion_decompile_decompylepp_2"]

def orion_decompile_fupy_2(filename, output="", restore_casesens=True, indent_count=4):
    from sys import stdout
    from os import path, makedirs, rename
    from fupy.fupy import PythonDecompiler, PythonDecompilerError
    indent_pattern = " "
    if indent_count > 0:
        indent_pattern = indent_pattern * indent_count
    if output == "":
        outstream = stdout
    else:
        try:
            outdir = path.dirname(output)
            if not path.isfile(outdir) and not path.isdir(outdir):
                makedirs(outdir) 
            outstream = open(output, "w")  
        except IOError:
          print("Error: cannot open '%s' for writing!" % output)
          return
    output2 = ""
    try:
        pydec = PythonDecompiler(filename)
        dump = pydec.decompile(indent = indent_pattern)
        outstream.write(dump)
        outstream.write("\n")
        output2 = pydec.pyc.code.co_filename
    except PythonDecompilerError as e:
        print("Error: " + str(e))
    finally:
        outstream.close()
    if restore_casesens and output != "" and output2 != "":
        if path.isfile(output):
            output = output.replace("/","\\")
            output2 = output2.replace("/","\\")
            if not path.splitext(output2)[1]:
                output2 += path.splitext(output)[1]
            output1 = output[::-1]
            output2 = output2[::-1] 
            output3 = ""
            for s in range(min(len(output1),len(output2))):
                 if output1[s].lower() == output2[s].lower():
                     output3 += output2[s]
                 else:
                     s -= 1
                     break
            s += 1
            output3 += output1[s:]
            output3 = output3[::-1]
            try:
                while s and output != output3:
                    rename(output, output3)
                    output, s = path.split(output)
                    output3 = path.split(output3)[0]
            except:
                pass

def orion_decompile_uncompyle6_2(filename, output="", restore_casesens=True):
    from sys import stdout
    from os import path, makedirs, rename
    from uncompyle6 import uncompyle_file
    if output == "":
        outstream = stdout
    else:
        outdir = path.dirname(output)
        if not path.isfile(outdir) and not path.isdir(outdir):
            makedirs(outdir)        
        outstream = open(output, "w")
    output2 = ""
    try:
        output2 = uncompyle_file(filename, outstream) 
        outstream.write("\n")
    except Exception as e:
        if outstream is not stdout and hasattr(e, "info"):
            outstream.write('\n'+e.info)
        print("Error: "+str(e))
    finally:
        outstream.close()
    if restore_casesens and output != "" and output2 != "":
        if path.isfile(output):
            output = output.replace("/","\\")
            output2 = output2.replace("/","\\")
            if not path.splitext(output2)[1]:
                output2 += path.splitext(output)[1]
            output1 = output[::-1]
            output2 = output2[::-1] 
            output3 = ""
            for s in range(min(len(output1),len(output2))):
                 if output1[s].lower() == output2[s].lower():
                     output3 += output2[s]
                 else:
                     s -= 1
                     break
            s += 1
            output3 += output1[s:]
            output3 = output3[::-1]
            try:
                while s and output != output3:
                    rename(output, output3)
                    output, s = path.split(output)
                    output3 = path.split(output3)[0]
            except:
                pass

def orion_decompile_pyretic_2(filename, output="", restore_casesens=True):
    from sys import stdout
    from os import path, makedirs, rename
    from pyretic.liveUnPYC import liveUnPYC
    if output == "":
        outstream = stdout
    else:
        outdir = path.dirname(output)
        if not path.isfile(outdir) and not path.isdir(outdir):
            makedirs(outdir)
        outstream = open(output, "w")
    output2 = ""
    try:
        live = liveUnPYC(None, None, False, False)
        outstream.write(live.fs_decompile(filename))
        outstream.write("\n")
        output2 = live.fs_filename(filename)
    except Exception as e:
        print("Error: "+str(e))
    finally:
        outstream.close()
    if restore_casesens and output != "" and output2 != "":
        if path.isfile(output):
            output = output.replace("/","\\")
            output2 = output2.replace("/","\\")
            if not path.splitext(output2)[1]:
                output2 += path.splitext(output)[1]
            output1 = output[::-1]
            output2 = output2[::-1] 
            output3 = ""
            for s in range(min(len(output1),len(output2))):
                 if output1[s].lower() == output2[s].lower():
                     output3 += output2[s]
                 else:
                     s -= 1
                     break
            s += 1
            output3 += output1[s:]
            output3 = output3[::-1]
            try:
                while s and output != output3:
                    rename(output, output3)
                    output, s = path.split(output)
                    output3 = path.split(output3)[0]
            except:
                pass

def orion_decompile_decompylepp_2(filename, output="", restore_casesens=True):
    from sys import stdout
    from os import path, makedirs, rename
    from shutil import rmtree
    from zipfile import ZipFile
    from tempfile import gettempdir
    import uuid, subprocess
    try:
        fn, _ = __file__.split(".zip")
        fh = open(fn + ".zip","rb")
        z = ZipFile(fh)
        nm = "dcpack/decompylepp/pycdc.exe"
        outpath = gettempdir()
        if outpath[-1] != "\\":
            outpath = outpath + "\\"
        outpath = outpath + str(uuid.uuid1()).replace("-", "") + "\\"
        z.extract(nm, outpath)
    except Exception as e:
        print("Error: "+str(e))
        return
    if output == "":
        outstream = stdout
    else:
        try:
            outdir = path.dirname(output)
            if not path.isfile(outdir) and not path.isdir(outdir):
                makedirs(outdir)            
            outstream = open(output, "w")
        except IOError:
          print("Error: cannot open '%s' for writing!" % output)
          rmtree(outpath,ignore_errors=True)
          return
    try:      
        outstream.write(subprocess.Popen([outpath+nm,filename],stdout=subprocess.PIPE).communicate()[0])
        outstream.write("\n")
    except Exception as e:
        print("Error: "+str(e))
    finally:
        outstream.close()
        rmtree(outpath,ignore_errors=True)
    if restore_casesens and output != "":
        if path.isfile(output):
            output2 = ""
            from marshal import loads
            with open(filename,'rb') as f:
                try:
                    output2 = loads(f.read()[8:]).co_filename
                except:
                    pass
            if output2 != "":
                output = output.replace("/","\\")
                output2 = output2.replace("/","\\")
                if not path.splitext(output2)[1]:
                    output2 += path.splitext(output)[1]
                output1 = output[::-1]
                output2 = output2[::-1] 
                output3 = ""
                for s in range(min(len(output1),len(output2))):
                     if output1[s].lower() == output2[s].lower():
                         output3 += output2[s]
                     else:
                         s -= 1
                         break
                s += 1
                output3 += output1[s:]
                output3 = output3[::-1]
                try:
                    while s and output != output3:
                        rename(output, output3)
                        output, s = path.split(output)
                        output3 = path.split(output3)[0]
                except:
                    pass