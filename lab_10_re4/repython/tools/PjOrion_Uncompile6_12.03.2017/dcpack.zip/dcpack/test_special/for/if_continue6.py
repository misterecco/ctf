for a in b:
    if a:
        print 1
        if b is not None and ((c and not d) or not f):
            continue
        print 2