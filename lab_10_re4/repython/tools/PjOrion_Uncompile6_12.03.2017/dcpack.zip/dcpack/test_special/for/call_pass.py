for a in b.d():
    pass