for a in b:
    if c:
        if not d:
            if f:
                continue
            a()