for a in b:
    if c:
        if d:
            print a
        continue