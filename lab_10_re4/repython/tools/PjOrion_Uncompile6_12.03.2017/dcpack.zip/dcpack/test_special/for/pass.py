for a in b:
    pass