for a in b:
    if c:
        print 123
    continue