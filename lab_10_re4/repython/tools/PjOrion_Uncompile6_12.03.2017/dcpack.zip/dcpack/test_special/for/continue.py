for a in b:
    continue