for a in b:
    if c:
        continue
else:
    print 123