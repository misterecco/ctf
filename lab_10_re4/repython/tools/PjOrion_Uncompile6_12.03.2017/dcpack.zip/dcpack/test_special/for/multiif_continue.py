for a in b:
    if d and f \
    or c and (a or \
    b):
        continue
    a = b