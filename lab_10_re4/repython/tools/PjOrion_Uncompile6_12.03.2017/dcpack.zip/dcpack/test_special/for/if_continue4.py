for a in b:
        if not b:
            if c:
                continue
            print 123
        continue
