for a in b:
        if not b:
            if not d:
                if c:
                    continue
                print 123
        continue