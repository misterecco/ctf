for a in b:
    if c:
        continue