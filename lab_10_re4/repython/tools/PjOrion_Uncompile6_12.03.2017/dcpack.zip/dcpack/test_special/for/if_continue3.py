for a in b:
    if c:
        if d:
            continue
        continue