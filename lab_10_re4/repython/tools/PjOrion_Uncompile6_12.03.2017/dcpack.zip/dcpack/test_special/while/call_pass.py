while a.b():
    pass