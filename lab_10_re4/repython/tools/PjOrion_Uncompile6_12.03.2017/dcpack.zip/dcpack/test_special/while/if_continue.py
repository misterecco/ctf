while a<b:
    if c:
        continue