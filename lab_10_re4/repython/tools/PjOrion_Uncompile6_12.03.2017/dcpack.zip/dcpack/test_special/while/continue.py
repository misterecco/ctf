while a:
    continue