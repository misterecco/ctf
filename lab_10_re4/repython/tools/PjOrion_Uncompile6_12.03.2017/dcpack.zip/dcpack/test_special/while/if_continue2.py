while a<b:
    if c:
        if d:
            print a
        continue