while a:
    break