while a<b:
    if c:
        if d:
            continue
        continue