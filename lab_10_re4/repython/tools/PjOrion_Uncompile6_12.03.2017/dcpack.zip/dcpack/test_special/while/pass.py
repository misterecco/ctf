while a:
    pass