try:
    a = 123
finally:
    print a