def a():
    return b if c<d else f