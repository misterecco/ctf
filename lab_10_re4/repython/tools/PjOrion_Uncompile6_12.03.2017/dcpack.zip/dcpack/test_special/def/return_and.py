def a():
    return b and c and d