def a():
    if c:
        if d:
            print a
        return