def a():
    if c:
        return