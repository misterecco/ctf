def a():
    return self.b[c] in self.f and \
           n and (self.f and n if self.k else True)