def a():
    if b in c:
        if d or m:
            print b
    return result