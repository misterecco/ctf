def a():
    if c:
        if d:
            return
        return