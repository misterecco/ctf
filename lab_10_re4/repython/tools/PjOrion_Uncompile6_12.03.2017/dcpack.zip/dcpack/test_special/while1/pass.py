while 123:
    pass