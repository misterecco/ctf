while 123:
    if c:
        if d:
            print 123
        continue