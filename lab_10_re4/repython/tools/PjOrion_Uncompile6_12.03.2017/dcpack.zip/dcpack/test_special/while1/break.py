while 123:
    break