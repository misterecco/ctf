while 123:
    continue