while 123:
    if c:
        continue