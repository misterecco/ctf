while 123:
    if c:
        if d:
            continue
        continue