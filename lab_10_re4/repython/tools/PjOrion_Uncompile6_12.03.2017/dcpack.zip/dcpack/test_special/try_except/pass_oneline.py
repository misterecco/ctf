try:pass
except:pass