try:
    a = 123
except:
    print a
else:
    print b
finally:
    print c