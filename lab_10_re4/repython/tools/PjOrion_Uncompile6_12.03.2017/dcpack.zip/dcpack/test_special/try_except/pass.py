try:
    pass
except:
    pass