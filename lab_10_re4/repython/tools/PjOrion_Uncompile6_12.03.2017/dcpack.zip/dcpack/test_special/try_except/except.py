try:
    a = 123
except:
    print a