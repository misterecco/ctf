if a and b and c:
    print 1
else:
    print b