if (a and b) or (c and d) or (f and g):
    print 1
else:
    print b