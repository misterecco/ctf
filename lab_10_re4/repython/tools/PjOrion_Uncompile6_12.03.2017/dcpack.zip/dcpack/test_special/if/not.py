if not a:
    print 1
else:
    print b