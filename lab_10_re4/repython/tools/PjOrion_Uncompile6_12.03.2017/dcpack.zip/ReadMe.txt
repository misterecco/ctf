------------------------------------------------------------------------
 The universal decompilation package for Python 2.5-3.5
------------------------------------------------------------------------

Last update: 28/07/2016

Uncompyle6 StranikS_Scan Edition (Python 2.6-3.5):
 - https://github.com/rocky/python-uncompyle6
 - https://github.com/rocky/python-spark/
 - https://github.com/Mysterie/uncompyle2
 - https://github.com/KenMacD/uncompyle2
 - https://github.com/ericfrederich/uncompyle2

Decompyle++ (Python 2.5-2.7):
 - https://github.com/zrax/pycdc
 - https://github.com/frainfreeze/pycdc

Fupy (Python 2.5-2.7):
 - https://code.google.com/p/fupy/
 - https://github.com/gdelugre/fupy

pyREtic (Python 2.5-2.7):
 - https://github.com/MyNameIsMeerkat/pyREtic

2016 (C) StranikS_Scan for http://www.koreanrandom.com/forum/