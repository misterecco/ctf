async def a(b, c):
    async for b in c:
        pass
