# From Python-3.5.2/Lib/multiprocessing/connection.py

def PipeClient(address):
    while 1:
        z = 2
    else:
        raise
    return
