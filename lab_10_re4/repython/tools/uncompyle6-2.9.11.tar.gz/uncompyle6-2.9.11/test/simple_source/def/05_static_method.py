@staticmethod
def square(n):
    return n * n
